from app.models.especie import Especie
from app.models.habitat import Habitat
from app.models.cuidador import Cuidador
from app.models.familia import Familia
from app.models.estado_conservacion import EstadoConservacion
from app.models.ubicacion import Ubicacion
from app.models.clima import Clima