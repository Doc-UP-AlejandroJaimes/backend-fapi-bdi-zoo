from fastapi import FastAPI, status
from fastapi.responses import JSONResponse
from app.routers import animales, especies, habitats, cuidadores
from fastapi.middleware.cors import CORSMiddleware
from fastapi.encoders import jsonable_encoder
from fastapi.exceptions import RequestValidationError
from mangum import Mangum


app = FastAPI()


ALLOWED_ORIGINS = [
    "http://localhost:5173",
    "http://localhost:3000",
    "https://frontend-fapi-bdi-zoo-uufi.vercel.app",
    "https://frontend-fapi-bdi-zoo-uufi-git-main-alejandrojaimes-projects.vercel.app",
    "https://frontend-fapi-bdi-zoo-uufi-28l6so2sp-alejandrojaimes-projects.vercel.app"
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

version_api = '/v1/'
app.include_router(animales.router, prefix=f"{version_api}animales", tags=["Animales"])
app.include_router(cuidadores.router, prefix=f"{version_api}cuidadores", tags=["Cuidadores"])
app.include_router(especies.router, prefix=f"{version_api}especies", tags=["Especies"])
app.include_router(habitats.router, prefix=f"{version_api}habitats", tags=["Habitats"])

handler = Mangum(app)

@app.get("/")
async def read_root():
    return {"message": "Hello World"}

@app.get("/error")
async def create_error():
    raise ValueError("This is a test error")

@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request, exc):
    headers = {
        'Access-Control-Allow-Origin'      : ', '.join(ALLOWED_ORIGINS),
        'Access-Control-Allow-Credentials' : 'true',
        'Access-Control-Allow-Methods'     : '*',
        'Access-Control-Allow-Headers'     : '*',
    }

    exc_str = ''

    for err in exc._errors:
        exc_str += f"{err['msg']} for input `{err['input']}` in the field {'->'.join(err['loc'])}. "

    return JSONResponse(
        jsonable_encoder(
            {
                "status_code" : 422,
                "message"     : exc_str,
                "exception"   : "HTTP_422_UNPROCESSABLE_ENTITY"
            }
        ),
        status_code = status.HTTP_422_UNPROCESSABLE_ENTITY,
        headers = headers
    )
